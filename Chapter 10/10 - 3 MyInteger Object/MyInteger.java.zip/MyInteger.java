package oop;
class MyInteger {
	int value = this.value;
	
	MyInteger() {
	}
	MyInteger(int newValue) {	
		value = newValue;
	}
	int getValue() {
		return value;
	}
	boolean isEven() {
	 if (value % 2 == 0) {	 
	 return true;
	 }
	 return false;
	}
	boolean isOdd() {
	 if (value % 2 != 0) {
	 return true;
	 }
	 return false;
	}
	boolean isPrime() {
		for (int p = 2; p <= value / 2; p++) {
			if (value % p == 0) {
			return false;
			}
		}
		return true;
	}
 
	public static boolean isEven(int e) {
		if (e % 2 == 0) {
			return true;
		}
		return false;
	}
	public static boolean isOdd(int o) {
		if (o % 2 != 0) {
			return true;
		}
		return false;
	}
	public static boolean isPrime(int p) {
		for (int i = 2; i <= p / 2; i++) {
			if (p % i == 0) {
			return false;
			}
		}
		return true;
	}	
	public static boolean isEven(MyInteger myinteger) {
		if(myinteger.isEven()) {
			return true;
		}
		return false;
	}
	public static boolean isOdd(MyInteger myinteger) {
		if(myinteger.isOdd()) {
			return true;
		}
		return false;
	}
	public static boolean isPrime(MyInteger myinteger) {
		if(myinteger.isPrime()) {
			return true;
		}
		return false;
	}
	boolean equals(int e) {
		if (this.value == e) {
			return true;
		}
		return false;
	}
	boolean equals(MyInteger MyInteger) {
		if (this.value == MyInteger.value) {
		return true;	
		}
		return false;
	}  

	public static int parseInt(char[] numbers) {
		int result = 0;
	    for (int i = 0; i < numbers.length; i++) {
	      result = result * 10 + (numbers[i] - '0');
	    }
	    return result;
	}
	public static int parseInt(String s) {
		return Integer.parseInt(s);
	}	
}	
