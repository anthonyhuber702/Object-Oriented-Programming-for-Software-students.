package oop;
 
public class testMyInteger {
 
	public static void main(String[] args) {
	MyInteger myinteger1 = new MyInteger(3);
	MyInteger myinteger2 = new MyInteger(72);
	System.out.println("Is myinteger1 equal to int 3: " + myinteger1.equals(3));
	System.out.println("Is 9 odd: " + MyInteger.isOdd(9));
	System.out.println("Is 10 even: " + MyInteger.isEven(10));
	System.out.println("Is myinteger1 == myinteger2: " + myinteger1.equals(myinteger2));
	System.out.println("Is myinteger1 even: " + MyInteger.isEven(myinteger2));
	if(myinteger1.isEven()) {
			System.out.println(myinteger1.getValue() + " is even");
		}
	else if (myinteger1.isOdd()) {
		System.out.println(myinteger1.getValue() + " is odd");
	}
	if (myinteger1.isPrime()) {
		System.out.println(myinteger1.getValue() + " is prime");
	}
	else System.out.println(myinteger1.getValue() + " is not prime");
	
	if(MyInteger.isEven(16)) {
		System.out.println("16 is even");
	}
	else if (MyInteger.isOdd(16)) {
	System.out.println("16 is odd");
	}
	if (MyInteger.isPrime(16)) {
	System.out.println("16 is prime");
	}
	else System.out.println("16 is not prime");
	
	if(myinteger1.isEven(myinteger1)) {
		System.out.println(myinteger1.getValue() + " is even");
	}
	else if (myinteger1.isOdd(myinteger1)) {
	System.out.println(myinteger1.getValue() + " is odd");
	}
	if (myinteger1.isPrime(myinteger1)) {
	System.out.println(myinteger1.getValue() + " is prime");
	}
	else System.out.println(myinteger1.getValue() + " is not prime");
	
	if(myinteger1.equals(myinteger2)) {
		System.out.print(myinteger1.getValue() + " and " + myinteger2.getValue() + " are equal");
	}
	else System.out.println(myinteger1.getValue() + " and " + myinteger2.getValue() + " are not equal");
	if(myinteger1.equals(3)) {
		System.out.println(myinteger1.getValue() + " and 3 are equal");
	}
	char[] testChar = {'3', '2', '1'};
	System.out.println("The characters '321' as numerical values is " + MyInteger.parseInt(testChar));
	System.out.println("The string '123' as a numerical value is " + MyInteger.parseInt("123"));
	}
}
